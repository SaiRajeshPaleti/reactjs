import React from "react";
import ReactDOM from "react-dom";
import { Google } from "./Google/google.component.jsx";

import "./styles.css";

function App() {
  return (
    <div className="App">
      <Google />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
