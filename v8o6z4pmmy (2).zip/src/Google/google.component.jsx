import React, { useState, useEffect } from "react";
import "./google.component.css";

export const Google = () => {
  //Initializing state
  const [isClick, setClick] = useState(false);
  const [wrapperRef, setwrapperRef] = useState();

  function setWrapperRef(node) {
    //setState
    setwrapperRef(node);
  }
  //removeFocus click on outside
  function handleClickOutside(event) {
    if (wrapperRef && !wrapperRef.contains(event.target)) {
      return setClick(false);
    }
  }
  function clearPlaceholder() {
    return setClick(true);
  }

  //Alternate to life cycle methods
  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    // Specify how to clean up after this effect:
    return function cleanup() {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  });
  //sppeech recognition
  // function startDictation() {
  //   if (window.hasOwnProperty("webkitSpeechRecognition")) {
  //     var recognition = new webkitSpeechRecognition();

  //     recognition.continuous = false;
  //     recognition.interimResults = false;

  //     recognition.lang = "en-US";
  //     recognition.start();

  //     recognition.onresult = function(e) {
  //       document.getElementById("transcript").value =
  //         e.results[0][0].transcript;
  //       recognition.stop();
  //       document.getElementById("text").value;
  //     };

  //     recognition.onerror = function(e) {
  //       recognition.stop();
  //     };
  //   }
  // }
  return (
    <form method="get" action="https://www.google.com/search">
      <div ref={setWrapperRef} className="googleDiv">
        <div className="googleImage">
          <img
            alt="google"
            src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png"
            className="google"
          />
        </div>
        <div className="search">
          <div className={isClick ? "" : "searchText"}>
            {isClick ? "" : "Search Google or type URL"}
          </div>
          <input type="url" onClick={clearPlaceholder} />
          <img
            alt="microphone"
            className="microphone"
            src="https://upload.wikimedia.org/wikipedia/commons/2/22/Google_microphone_logo.png"
          />
        </div>
      </div>
    </form>
  );
};
